package com.project.performanceTrack.service;

import com.project.performanceTrack.entity.Notification;
import com.project.performanceTrack.entity.User;
import com.project.performanceTrack.enums.NotificationStatus;
import com.project.performanceTrack.enums.NotificationType;
import com.project.performanceTrack.enums.UserRole;
import com.project.performanceTrack.exception.ResourceNotFoundException;
import com.project.performanceTrack.repository.NotificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for NotificationService.
 *
 * Tests notification creation, retrieval, and mark-as-read functionality.
 */
@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository notifRepo;

    @Mock
    private SseEmitterService sseEmitterService;

    @InjectMocks
    private NotificationService notificationService;

    private User testUser;
    private Notification testNotification;

    @BeforeEach
    void setUp() {
        testUser = new User();
        testUser.setUserId(1);
        testUser.setName("John");
        testUser.setRole(UserRole.EMPLOYEE);

        testNotification = new Notification();
        testNotification.setNotificationId(1);
        testNotification.setUser(testUser);
        testNotification.setType(NotificationType.GOAL_APPROVED);
        testNotification.setMessage("Your goal was approved");
        testNotification.setStatus(NotificationStatus.UNREAD);
    }

    // ==================== sendNotification() ====================

    @Test
    @DisplayName("sendNotification() should save notification and push via SSE")
    void sendNotification_ShouldSaveAndPush() {
        // Arrange
        when(notifRepo.save(any(Notification.class))).thenAnswer(invocation -> {
            Notification saved = invocation.getArgument(0);
            saved.setNotificationId(10);
            return saved;
        });

        // Act
        notificationService.sendNotification(
                testUser, NotificationType.GOAL_APPROVED,
                "Your goal was approved", "Goal", 1, "HIGH", false
        );

        // Assert
        verify(notifRepo).save(any(Notification.class));
        verify(sseEmitterService).sendToUser(eq(1), any(Notification.class));
    }

    @Test
    @DisplayName("sendNotification() should set default priority to NORMAL when null")
    void sendNotification_WithNullPriority_ShouldDefaultToNormal() {
        when(notifRepo.save(any(Notification.class))).thenAnswer(invocation -> {
            Notification saved = invocation.getArgument(0);
            // Verify default priority is set
            assertEquals("NORMAL", saved.getPriority());
            saved.setNotificationId(10);
            return saved;
        });

        notificationService.sendNotification(
                testUser, NotificationType.GOAL_APPROVED,
                "Message", "Goal", 1, null, false
        );

        verify(notifRepo).save(any(Notification.class));
    }

    // ==================== getNotifications() (List version) ====================

    @Test
    @DisplayName("getNotifications() should filter by status when provided")
    void getNotifications_WithStatus_ShouldFilterByStatus() {
        when(notifRepo.findByUser_UserIdAndStatusOrderByCreatedDateDesc(1, NotificationStatus.UNREAD))
                .thenReturn(Arrays.asList(testNotification));

        List<Notification> result = notificationService.getNotifications(1, "UNREAD");

        assertEquals(1, result.size());
        assertEquals(NotificationStatus.UNREAD, result.get(0).getStatus());
    }

    @Test
    @DisplayName("getNotifications() should return all when no status filter")
    void getNotifications_WithoutStatus_ShouldReturnAll() {
        when(notifRepo.findByUser_UserIdOrderByCreatedDateDesc(1))
                .thenReturn(Arrays.asList(testNotification));

        List<Notification> result = notificationService.getNotifications(1, null);

        assertEquals(1, result.size());
    }

    // ==================== getNotifications() (Paginated version) ====================

    @Test
    @DisplayName("getNotifications() paginated should filter by status")
    void getNotifications_Paginated_WithStatus_ShouldFilter() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Notification> page = new PageImpl<>(Arrays.asList(testNotification), pageable, 1);
        when(notifRepo.findByUser_UserIdAndStatus(1, NotificationStatus.UNREAD, pageable)).thenReturn(page);

        Page<Notification> result = notificationService.getNotifications(1, "UNREAD", pageable);

        assertEquals(1, result.getTotalElements());
    }

    @Test
    @DisplayName("getNotifications() paginated should return all when status is null")
    void getNotifications_Paginated_WithoutStatus_ShouldReturnAll() {
        Pageable pageable = PageRequest.of(0, 10);
        Page<Notification> page = new PageImpl<>(Arrays.asList(testNotification), pageable, 1);
        when(notifRepo.findByUser_UserId(1, pageable)).thenReturn(page);

        Page<Notification> result = notificationService.getNotifications(1, null, pageable);

        assertEquals(1, result.getTotalElements());
    }

    // ==================== markAsRead() ====================

    @Test
    @DisplayName("markAsRead() should change status to READ and set readDate")
    void markAsRead_ShouldUpdateStatus() {
        when(notifRepo.findById(1)).thenReturn(Optional.of(testNotification));
        when(notifRepo.save(any(Notification.class))).thenReturn(testNotification);

        Notification result = notificationService.markAsRead(1);

        assertEquals(NotificationStatus.READ, result.getStatus());
        assertNotNull(result.getReadDate());
    }

    @Test
    @DisplayName("markAsRead() should throw ResourceNotFoundException when not found")
    void markAsRead_WithInvalidId_ShouldThrowException() {
        when(notifRepo.findById(999)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> notificationService.markAsRead(999));
    }

    // ==================== markAllAsRead() ====================

    @Test
    @DisplayName("markAllAsRead() should mark all unread notifications as read")
    void markAllAsRead_ShouldUpdateAllUnread() {
        Notification notif1 = new Notification();
        notif1.setStatus(NotificationStatus.UNREAD);
        Notification notif2 = new Notification();
        notif2.setStatus(NotificationStatus.UNREAD);

        when(notifRepo.findByUser_UserIdAndStatusOrderByCreatedDateDesc(1, NotificationStatus.UNREAD))
                .thenReturn(Arrays.asList(notif1, notif2));

        notificationService.markAllAsRead(1);

        // Both notifications should now be READ
        assertEquals(NotificationStatus.READ, notif1.getStatus());
        assertEquals(NotificationStatus.READ, notif2.getStatus());
        assertNotNull(notif1.getReadDate());
        assertNotNull(notif2.getReadDate());
        verify(notifRepo).saveAll(anyList());
    }
}
