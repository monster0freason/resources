package com.project.performanceTrack.controller;

import com.project.performanceTrack.dto.ApiResponse;
import com.project.performanceTrack.dto.PageResponse;
import com.project.performanceTrack.entity.Notification;
import com.project.performanceTrack.enums.NotificationStatus;
import com.project.performanceTrack.enums.NotificationType;
import com.project.performanceTrack.service.NotificationService;
import com.project.performanceTrack.service.SseEmitterService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for NotificationController.
 */
@ExtendWith(MockitoExtension.class)
class NotificationControllerTest {

    @Mock
    private NotificationService notificationService;

    @Mock
    private SseEmitterService sseEmitterService;

    @InjectMocks
    private NotificationController notificationController;

    private Notification testNotification;
    private MockHttpServletRequest mockRequest;

    @BeforeEach
    void setUp() {
        testNotification = new Notification();
        testNotification.setNotificationId(1);
        testNotification.setType(NotificationType.GOAL_APPROVED);
        testNotification.setMessage("Your goal was approved");
        testNotification.setStatus(NotificationStatus.UNREAD);

        mockRequest = new MockHttpServletRequest();
        mockRequest.setAttribute("userId", 1);
    }

    @Test
    @DisplayName("stream() should return SSE emitter for real-time notifications")
    void stream_ShouldReturnSseEmitter() {
        SseEmitter mockEmitter = new SseEmitter();
        when(sseEmitterService.createEmitter(1)).thenReturn(mockEmitter);

        SseEmitter result = notificationController.stream(mockRequest);

        assertNotNull(result);
        verify(sseEmitterService).createEmitter(1);
    }

    @Test
    @DisplayName("getNotifications() should return paginated notifications")
    void getNotifications_ShouldReturnPagedNotifications() {
        Page<Notification> page = new PageImpl<>(Arrays.asList(testNotification));
        when(notificationService.getNotifications(eq(1), isNull(), any(Pageable.class)))
                .thenReturn(page);

        ApiResponse<PageResponse<Notification>> response =
                notificationController.getNotifications(mockRequest, null, 0, 20);

        assertEquals("success", response.getStatus());
        assertEquals("Notifications retrieved", response.getMsg());
    }

    @Test
    @DisplayName("markAsRead() should return updated notification")
    void markAsRead_ShouldReturnUpdatedNotification() {
        testNotification.setStatus(NotificationStatus.READ);
        when(notificationService.markAsRead(1)).thenReturn(testNotification);

        ApiResponse<Notification> response = notificationController.markAsRead(1);

        assertEquals("success", response.getStatus());
        assertEquals("Notification marked as read", response.getMsg());
    }

    @Test
    @DisplayName("markAllAsRead() should return success")
    void markAllAsRead_ShouldReturnSuccess() {
        ApiResponse<Void> response = notificationController.markAllAsRead(mockRequest);

        assertEquals("success", response.getStatus());
        assertEquals("All notifications marked as read", response.getMsg());
        verify(notificationService).markAllAsRead(1);
    }
}
