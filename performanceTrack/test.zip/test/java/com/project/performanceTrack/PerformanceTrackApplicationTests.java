package com.project.performanceTrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerformanceTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
